ShowMessage('Hello from Altium DelphiScript!');
