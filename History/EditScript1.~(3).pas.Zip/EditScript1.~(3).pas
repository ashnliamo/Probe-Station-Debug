procedure TestMessage;
begin
    ShowMessage('Hello from Altium DelphiScript!');
end;
