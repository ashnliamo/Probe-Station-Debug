








  procedure TestMessage;
begin
    ShowMessage('Hello from Altium DelphiScript!');
end;
procedure TestMessage2;
begin
    ShowMessage('Hello from Altium DelphiScript!');
end;
