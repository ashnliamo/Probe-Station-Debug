"""Probe-card PCB generator (Altium).

Reads a CSV of die probing-pad coordinates and produces, for the manufacturable
probe card:

  * <stem>_probe_card.pas -- an Altium DelphiScript. Run it in Altium Designer
        (File > Run Script..., GenerateProbeCard) to build the PCB: 4.5" outline,
        circular aperture cutout, round through-hole solder lands (1000 um pad,
        0.02" plated hole) with silk signal labels, plus reference die/die-pads/
        probe-wires and a keep-out marker on non-fabricated mechanical layers.
  * <stem>_wiring_map.csv -- maps every land -> signal + position.

Probe lands fan out onto a rectangle scaled from the die so every land is
>= EDGE_CLEARANCE from the die edge and the 1000 um lands never collide; within
each side the lands keep die order and minimise lateral deviation (optimal L2
fan-out) -> minimum probe length, no crossing, no collision.
"""

import csv
import math
import pathlib

HERE = pathlib.Path(__file__).parent
INPUT_DIR = HERE / "auto_probe_pcb_inputs"
OUTPUT_DIR = HERE / "auto_probe_pcb_outputs"
COL_PAD, COL_SIGNAL, COL_X, COL_Y = ("pad", "signal", "x (um)", "y (um)")

# --- geometry, all in um ---
DIE_X = 8170.73             # die "length" (x extent)
DIE_Y = 5155.584            # die "width"  (y extent)
DIE_PAD_SIDE = 80           # chip probing-pad size
PROBE_PAD_SIDE = 1000       # probe soldering-land size (annular copper OD)
PROBE_PAD_CLEARANCE = 200   # min gap between adjacent probe lands
PROBE_PAD_PITCH = PROBE_PAD_SIDE + PROBE_PAD_CLEARANCE
EDGE_CLEARANCE = 25000      # 3 cm: min distance from a probe land to the die edge

BOARD_CENTER = (4000 * 25.4, 3000 * 25.4)   # place board/die centre here (um);
                                            # 4000 x 3000 mil -> keeps board on-sheet
VIA_DRILL = 508             # 0.02" plated through-hole (um)
CARD_SIZE = 114300          # 4.5" square board outline (um)
APERTURE_CLEARANCE = 10000  # 1 cm: die's nearest point (corner) to circular aperture edge
KEEP_OUT_DISTANCE = 15000   # 15 mm: min die-to-keep-out-rectangle clearance (all sides)

LABEL_SIZE = 400            # signal-label text height (um)
LABEL_THICK = 60            # label stroke width (um)
LABEL_GAP = 200             # gap from land edge to start of its label (um)
PROBE_WIRE_WIDTH = 150      # visual probe-needle line width (um); not fabricated
MARKER_LINE = 150           # marker-rectangle line width (um); not fabricated

# --- Altium DelphiScript export layers (mechanical layers used for docs) ---
ALTIUM_MARKER_LAYER  = "eMechanical15"   # die-aspect keep-out marker rectangle
ALTIUM_REF_LAYER     = "eMechanical13"   # die, die pads, probe wires (reference)


# ----------------------------------------------------------------------------
# input
# ----------------------------------------------------------------------------
def read_pads(csv_path):
    with open(csv_path, newline="") as f:
        rows = list(csv.reader(f))
    header_idx = None
    for i, row in enumerate(rows):
        cells = [c.strip().lower() for c in row]
        if COL_X in cells and COL_Y in cells:
            header_idx, header = i, cells
            break
    if header_idx is None:
        raise ValueError(f"No header row with '{COL_X}' and '{COL_Y}'.")
    ix, iy = header.index(COL_X), header.index(COL_Y)
    ipad = header.index(COL_PAD) if COL_PAD in header else None
    isig = header.index(COL_SIGNAL) if COL_SIGNAL in header else None
    pads = []
    for row in rows[header_idx + 1:]:
        if len(row) <= max(ix, iy):
            continue
        try:
            x, y = float(row[ix]), float(row[iy])
        except ValueError:
            continue
        name = row[ipad].strip() if ipad is not None and ipad < len(row) else ""
        signal = row[isig].strip() if isig is not None and isig < len(row) else ""
        pads.append({"name": name, "signal": signal, "x": x, "y": y})
    return pads


# ----------------------------------------------------------------------------
# layout math
# ----------------------------------------------------------------------------
def die_center(pads):
    xs = [p["x"] for p in pads]
    ys = [p["y"] for p in pads]
    return (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0


def classify_side(pad, cx, cy):
    nx = (pad["x"] - cx) / (DIE_X / 2.0)
    ny = (pad["y"] - cy) / (DIE_Y / 2.0)
    if abs(nx) >= abs(ny):
        return "R" if nx > 0 else "L"
    return "T" if ny > 0 else "B"


def group_by_side(pads, cx, cy):
    sides = {"T": [], "B": [], "L": [], "R": []}
    for p in pads:
        sides[classify_side(p, cx, cy)].append(p)
    return sides


def pava_min_pitch(targets, pitch):
    """Place points near sorted `targets` with consecutive gap >= pitch,
    minimising sum of squared deviation (pool-adjacent-violators). Keeps order."""
    n = len(targets)
    if n == 0:
        return []
    a = [targets[i] - i * pitch for i in range(n)]
    blocks = []  # [mean, count]
    for x in a:
        blocks.append([x, 1])
        while len(blocks) >= 2 and blocks[-2][0] > blocks[-1][0]:
            m2, c2 = blocks.pop()
            m1, c1 = blocks.pop()
            blocks.append([(m1 * c1 + m2 * c2) / (c1 + c2), c1 + c2])
    z = []
    for m, c in blocks:
        z.extend([m] * c)
    return [z[i] + i * pitch for i in range(n)]


def required_scale(sides):
    """Smallest uniform scale of the die rectangle so the aperture clears the die
    by EDGE_CLEARANCE on every side AND each side fits its lands without collision."""
    s = 1.0 + 2.0 * EDGE_CLEARANCE / min(DIE_X, DIE_Y)
    for side, pads in sides.items():
        if not pads:
            continue
        need = (len(pads) - 1) * PROBE_PAD_PITCH + PROBE_PAD_SIDE
        die_dim = DIE_X if side in ("T", "B") else DIE_Y
        s = max(s, need / die_dim)
    return s


def place_probes(sides, cx, cy, scale):
    """Return probe land dicts: {x, y, side, id, die}."""
    half_ax = scale * DIE_X / 2.0
    half_ay = scale * DIE_Y / 2.0
    probes = []
    for side, pads in sides.items():
        if not pads:
            continue
        if side in ("T", "B"):
            pads = sorted(pads, key=lambda p: p["x"])
            xs = pava_min_pitch([p["x"] for p in pads], PROBE_PAD_PITCH)
            y = cy + half_ay if side == "T" else cy - half_ay
            coords = [(x, y) for x in xs]
        else:
            pads = sorted(pads, key=lambda p: p["y"])
            ys = pava_min_pitch([p["y"] for p in pads], PROBE_PAD_PITCH)
            x = cx + half_ax if side == "R" else cx - half_ax
            coords = [(x, yy) for yy in ys]
        for i, (p, (x, y)) in enumerate(zip(pads, coords), start=1):
            probes.append({"x": x, "y": y, "side": side,
                           "id": f"{side}{i}", "die": p})
    return probes


def compute_layout(pads):
    # translate all pads so the die/board centre sits at BOARD_CENTER
    cx0, cy0 = die_center(pads)
    dx, dy = BOARD_CENTER[0] - cx0, BOARD_CENTER[1] - cy0
    for p in pads:
        p["x"] += dx
        p["y"] += dy
    cx, cy = die_center(pads)
    sides = group_by_side(pads, cx, cy)
    scale = required_scale(sides)
    probes = place_probes(sides, cx, cy, scale)
    return {"cx": cx, "cy": cy, "sides": sides, "scale": scale, "probes": probes}


def aperture_radius():
    """Circular aperture radius: 1 cm beyond the die's nearest point to the
    circle -- i.e. the die corner (half-diagonal), which is the closest the
    die gets to a circle centred on it."""
    return math.hypot(DIE_X / 2.0, DIE_Y / 2.0) + APERTURE_CLEARANCE


def marker_dims():
    """A rectangle with the die's aspect ratio, scaled so the die is
    >= KEEP_OUT_DISTANCE from it on every side (the smaller die dimension is the
    binding one)."""
    s = 1.0 + 2.0 * KEEP_OUT_DISTANCE / min(DIE_X, DIE_Y)
    return s * DIE_X, s * DIE_Y


# ----------------------------------------------------------------------------
# card-fit check
# ----------------------------------------------------------------------------
def check_fit(L):
    """Warn if any land leaves the 4.5" card, or the copper frame is thin."""
    cx, cy = L["cx"], L["cy"]
    half = CARD_SIZE / 2.0
    edge = PROBE_PAD_SIDE / 2.0
    worst = min(min(half - abs(pr["x"] - cx), half - abs(pr["y"] - cy))
                for pr in L["probes"]) - edge
    frame_lr = half - (L["scale"] * DIE_X / 2.0)  # card edge to left/right lands
    if worst < 0:
        print(f"  WARNING: lands extend {-worst:.0f} um past the card outline.")
    else:
        print(f"  Min land-to-card-edge clearance: {worst:.0f} um.")
    print(f"  Left/right copper frame width ~ {frame_lr - PROBE_PAD_SIDE/2:.0f} um.")


# ----------------------------------------------------------------------------
# outputs
# ----------------------------------------------------------------------------
def _altium_label(pr):
    """Anchor (mm), rotation (deg) and text for an Altium silk label, placed so
    it reads radially outward. Altium stroke text is anchored bottom-left and
    extends up/right, so left/bottom labels are shifted by an estimated length."""
    off = (PROBE_PAD_SIDE / 2.0 + LABEL_GAP + 250) / 1000.0
    h = LABEL_SIZE / 1000.0
    x, y = pr["x"] / 1000.0, pr["y"] / 1000.0
    sig = pr["die"]["signal"] or pr["id"]
    # over-estimate the rendered length so bottom/left labels (anchored at their
    # far end) keep their NEAR end clear of the pad instead of overrunning it.
    ln = max(1, len(sig)) * h * 1.1
    if pr["side"] == "T":
        return (x - h / 2, y + off, 90.0, sig)
    if pr["side"] == "B":
        return (x - h / 2, y - off - ln, 90.0, sig)
    if pr["side"] == "L":
        return (x - off - ln, y - h / 2, 0.0, sig)
    return (x + off, y - h / 2, 0.0, sig)  # R


def _pas_str(s):
    return "'" + s.replace("'", "''") + "'"


def write_altium_script(path, pads, L):
    """Emit a self-contained Altium DelphiScript (.pas). Run it in Altium
    Designer (File > Run Script..., choose GenerateProbeCard) to build the probe
    card: 4.5" outline, circular aperture cutout, round through-hole solder lands
    (1000 um pad, 0.02" plated hole) with silk signal labels, and reference
    die/die-pads/probe-wires + keep-out marker on non-fabricated mech layers."""
    cx, cy = L["cx"], L["cy"]
    H = CARD_SIZE / 2.0
    APR = aperture_radius()          # circular aperture radius (um)
    MW, MH = marker_dims()           # marker rectangle size (um)
    PAD = PROBE_PAD_SIDE / 1000.0
    HOLE = VIA_DRILL / 1000.0
    TEXTH = LABEL_SIZE / 1000.0
    TEXTW = LABEL_THICK / 1000.0
    PROBEW = PROBE_WIRE_WIDTH / 1000.0
    DIEPAD = DIE_PAD_SIDE / 1000.0

    def mm(v):
        return f"{v:.4f}"

    o = []
    w = o.append
    # ---- header + helpers (// comments so no { } clash) ----
    w(f"""// Auto-generated by auto_probe_pcb.py -- Altium DelphiScript.
// In Altium Designer: File > Run Script..., then run GenerateProbeCard.
// Builds the probe-card PCB.

Var
    Board : IPCB_Board;

Procedure RegisterObj(Obj);
Begin
    Board.AddPCBObject(Obj);
    PCBServer.SendMessageToRobots(Board.I_ObjectAddress, c_Broadcast,
        PCBM_BoardRegisteration, Obj.I_ObjectAddress);
End;

Procedure AddLand(XMM, YMM : Double; Desig : String);
Var Pad;
Begin
    Pad := PCBServer.PCBObjectFactory(ePadObject, eNoDimension, eCreate_Default);
    Pad.X := MMsToCoord(XMM);
    Pad.Y := MMsToCoord(YMM);
    Pad.Layer := eMultiLayer;
    Pad.TopShape := eRounded;
    Pad.MidShape := eRounded;
    Pad.BotShape := eRounded;
    Pad.TopXSize := MMsToCoord({mm(PAD)}); Pad.TopYSize := MMsToCoord({mm(PAD)});
    Pad.MidXSize := MMsToCoord({mm(PAD)}); Pad.MidYSize := MMsToCoord({mm(PAD)});
    Pad.BotXSize := MMsToCoord({mm(PAD)}); Pad.BotYSize := MMsToCoord({mm(PAD)});
    Pad.HoleSize := MMsToCoord({mm(HOLE)});
    Pad.Plated := True;
    Pad.Name := Desig;
    RegisterObj(Pad);
End;

Procedure AddText(XMM, YMM, Rot : Double; S : String);
Var T;
Begin
    T := PCBServer.PCBObjectFactory(eTextObject, eNoDimension, eCreate_Default);
    T.XLocation := MMsToCoord(XMM);
    T.YLocation := MMsToCoord(YMM);
    T.Layer := eTopOverlay;
    T.Size := MMsToCoord({mm(TEXTH)});
    T.Width := MMsToCoord({mm(TEXTW)});
    T.Rotation := Rot;
    T.Text := S;
    RegisterObj(T);
End;

Procedure AddRefTrack(X1, Y1, X2, Y2, Wid : Double);
Var Tr;
Begin
    Tr := PCBServer.PCBObjectFactory(eTrackObject, eNoDimension, eCreate_Default);
    Tr.X1 := MMsToCoord(X1); Tr.Y1 := MMsToCoord(Y1);
    Tr.X2 := MMsToCoord(X2); Tr.Y2 := MMsToCoord(Y2);
    Tr.Width := MMsToCoord(Wid);
    Tr.Layer := {ALTIUM_REF_LAYER};
    RegisterObj(Tr);
End;

Procedure AddRefRect(X1, Y1, X2, Y2, Wid : Double);
Begin
    AddRefTrack(X1, Y1, X2, Y1, Wid);
    AddRefTrack(X2, Y1, X2, Y2, Wid);
    AddRefTrack(X2, Y2, X1, Y2, Wid);
    AddRefTrack(X1, Y2, X1, Y1, Wid);
End;

Procedure AddDiePad(XMM, YMM : Double);
Var Hf;
Begin
    Hf := {mm(DIEPAD / 2.0)};
    AddRefRect(XMM - Hf, YMM - Hf, XMM + Hf, YMM + Hf, 0.02);
End;

Procedure AddProbe(X1, Y1, X2, Y2 : Double);
Begin
    AddRefTrack(X1, Y1, X2, Y2, {mm(PROBEW)});
End;

// --- everything belonging to one probe: the solder land, its silk label,
// --- the die pad it probes, and the probe needle between them.
Procedure EmitLand(LX, LY : Double; Desig : String;
                   TX, TY, Rot : Double; Sig : String; DX, DY : Double);
Begin
    AddLand(LX, LY, Desig);
    AddText(TX, TY, Rot, Sig);
    AddDiePad(DX, DY);
    AddProbe(LX, LY, DX, DY);
End;

// --- board shape: rectangular outline. Standard resize-outline pattern;
// --- may need tweaking per Altium version.
Procedure SetRectBoard(X1, Y1, X2, Y2 : Double);
Begin
    Board.BoardOutline.Invalidate;
    Board.BoardOutline.PointCount := 4;
    Board.BoardOutline.Segments[0].Kind := ePolySegmentLine;
    Board.BoardOutline.Segments[0].vx := MMsToCoord(X1);
    Board.BoardOutline.Segments[0].vy := MMsToCoord(Y1);
    Board.BoardOutline.Segments[1].Kind := ePolySegmentLine;
    Board.BoardOutline.Segments[1].vx := MMsToCoord(X2);
    Board.BoardOutline.Segments[1].vy := MMsToCoord(Y1);
    Board.BoardOutline.Segments[2].Kind := ePolySegmentLine;
    Board.BoardOutline.Segments[2].vx := MMsToCoord(X2);
    Board.BoardOutline.Segments[2].vy := MMsToCoord(Y2);
    Board.BoardOutline.Segments[3].Kind := ePolySegmentLine;
    Board.BoardOutline.Segments[3].vx := MMsToCoord(X1);
    Board.BoardOutline.Segments[3].vy := MMsToCoord(Y2);
    Board.BoardOutline.Validate;
End;

// --- circular aperture: board-cutout region approximated by a 72-gon.
// --- The region-contour API is the part most likely to need adjustment
// --- for your Altium version.
Procedure AddCircleCutout(CXmm, CYmm, Rmm : Double);
Var Rgn, C, i, ang;
Begin
    Rgn := PCBServer.PCBObjectFactory(eRegionObject, eNoDimension, eCreate_Default);
    Rgn.SetState_Kind(eRegionKind_BoardCutout);
    C := PCBServer.PCBContourFactory;
    For i := 0 To 71 Do
    Begin
        ang := i * 6.28318530717959 / 72.0;
        C.AddPoint(MMsToCoord(CXmm + Rmm * Cos(ang)), MMsToCoord(CYmm + Rmm * Sin(ang)));
    End;
    Rgn.SetOutlineContour(C);
    Rgn.Layer := eTopLayer;
    RegisterObj(Rgn);
End;

// --- die-aspect clearance marker on a non-fabricated mechanical layer.
Procedure AddMarkerTrack(X1, Y1, X2, Y2, Wid : Double);
Var Tr;
Begin
    Tr := PCBServer.PCBObjectFactory(eTrackObject, eNoDimension, eCreate_Default);
    Tr.X1 := MMsToCoord(X1); Tr.Y1 := MMsToCoord(Y1);
    Tr.X2 := MMsToCoord(X2); Tr.Y2 := MMsToCoord(Y2);
    Tr.Width := MMsToCoord(Wid);
    Tr.Layer := {ALTIUM_MARKER_LAYER};
    RegisterObj(Tr);
End;

Procedure AddMarkerRect(X1, Y1, X2, Y2, Wid : Double);
Begin
    AddMarkerTrack(X1, Y1, X2, Y1, Wid);
    AddMarkerTrack(X2, Y1, X2, Y2, Wid);
    AddMarkerTrack(X2, Y2, X1, Y2, Wid);
    AddMarkerTrack(X1, Y2, X1, Y1, Wid);
End;
""")

    # ---- one EmitLand call per probe: land + label + die pad + needle ----
    w("Procedure BuildAll;\nBegin")
    for pr in L["probes"]:
        d = pr["die"]
        lx, ly, rot, sig = _altium_label(pr)
        w(f"    EmitLand({mm(pr['x']/1000)}, {mm(pr['y']/1000)}, {_pas_str(pr['id'])}, "
          f"{mm(lx)}, {mm(ly)}, {mm(rot)}, {_pas_str(sig)}, "
          f"{mm(d['x']/1000)}, {mm(d['y']/1000)});")
    w("End;\n")

    # ---- entry point ----
    w(f"""Procedure GenerateProbeCard;
Begin
    If PCBServer = Nil Then
    Begin
        ShowMessage('PCBServer is nil -- the PCB editor is not loaded.');
        Exit;
    End;
    Board := PCBServer.GetCurrentPCBBoard;
    If Board = Nil Then
    Begin
        ShowMessage('No PCB is open. Create a blank PCB first: ' +
            'File > New > PCB, make that tab active, then run this script again.');
        Exit;
    End;
    PCBServer.PreProcess;
    SetRectBoard({mm((cx-H)/1000)}, {mm((cy-H)/1000)}, {mm((cx+H)/1000)}, {mm((cy+H)/1000)});
    AddCircleCutout({mm(cx/1000)}, {mm(cy/1000)}, {mm(APR/1000)});
    AddMarkerRect({mm((cx-MW/2)/1000)}, {mm((cy-MH/2)/1000)}, {mm((cx+MW/2)/1000)}, {mm((cy+MH/2)/1000)}, {mm(MARKER_LINE/1000)});
    AddRefRect({mm((cx-DIE_X/2)/1000)}, {mm((cy-DIE_Y/2)/1000)}, {mm((cx+DIE_X/2)/1000)}, {mm((cy+DIE_Y/2)/1000)}, 0.05);
    BuildAll;
    PCBServer.PostProcess;
    Board.ViewManager_FullUpdate;
    Client.SendMessage('PCB:Zoom', 'Action=Redraw', 255, Client.CurrentView);
    ShowMessage('Probe card built on the active PCB. ' +
        'Use File > Save As to save it as a .PcbDoc.');
End;
""")

    with open(path, "w", newline="\n") as f:
        f.write("\n".join(o))


def write_wiring_map(path, L):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["land_id", "side", "signal", "die_pad",
                    "land_x_mm", "land_y_mm", "die_x_um", "die_y_um"])
        for pr in L["probes"]:
            d = pr["die"]
            w.writerow([pr["id"], pr["side"], d["signal"], d["name"],
                        f"{pr['x']/1000:.3f}", f"{pr['y']/1000:.3f}",
                        f"{d['x']:.3f}", f"{d['y']:.3f}"])


def find_input_csv():
    csvs = sorted(INPUT_DIR.glob("*.csv"))
    if not csvs:
        raise SystemExit(f"No .csv found in {INPUT_DIR} -- put your pinout there.")
    if len(csvs) > 1:
        names = ", ".join(p.name for p in csvs)
        raise SystemExit(f"Multiple .csv files in {INPUT_DIR} ({names}); keep just one.")
    return csvs[0]


def main():
    csv_path = find_input_csv()
    pads = read_pads(csv_path)
    L = compute_layout(pads)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    counts = {s: len(v) for s, v in L["sides"].items()}
    print(f"Die {DIE_X} x {DIE_Y} um, centre ({L['cx']:.1f}, {L['cy']:.1f})")
    print(f"Per-side pad counts: {counts}")
    print(f"Aperture scale x{L['scale']:.2f} -> "
          f"{L['scale']*DIE_X/1000:.1f} x {L['scale']*DIE_Y/1000:.1f} mm")
    check_fit(L)

    map_path = OUTPUT_DIR / f"{csv_path.stem}_wiring_map.csv"
    write_wiring_map(map_path, L)
    print(f"Wrote wiring map:   {map_path}")

    pas_path = OUTPUT_DIR / f"{csv_path.stem}_probe_card.pas"
    write_altium_script(pas_path, pads, L)
    print(f"Wrote Altium script:{pas_path}")

    print(f"{len(pads)} die pads / {len(L['probes'])} probe lands "
          f"({VIA_DRILL} um dia drill, {PROBE_PAD_SIDE} um land).")


if __name__ == "__main__":
    main()

